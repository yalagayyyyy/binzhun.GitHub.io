package com.example.eurekaclientprovider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaClientProviderApplicationTests {

	@Test
	void contextLoads() {
	}

}
