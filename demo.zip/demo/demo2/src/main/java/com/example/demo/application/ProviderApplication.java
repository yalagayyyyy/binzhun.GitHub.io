package com.example.demo.application;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@EnableEurekaClient
@RestController
public class ProviderApplication {
    public static void main(String[] args) {
        SpringApplication.run( ProviderApplication.class, args );
    }
    @Value("${server.port}")
    String port;
    @GetMapping("/hello")
    public String hello(@RequestParam String name) {
        return "hello, " + name + ", 我是服务提供者:端口为：" + port;
    }
}