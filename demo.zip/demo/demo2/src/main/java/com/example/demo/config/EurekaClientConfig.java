package com.example.demo.config;


import com.netflix.appinfo.ApplicationInfoManager;
import com.netflix.appinfo.EurekaInstanceConfig;
import com.netflix.appinfo.InstanceInfo;
import org.springframework.cloud.netflix.eureka.InstanceInfoFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EurekaClientConfig {

    @Bean
    public ApplicationInfoManager applicationInfoManager(EurekaInstanceConfig instanceConfig) {
        InstanceInfo instanceInfo = new InstanceInfoFactory().create(instanceConfig);
        return new ApplicationInfoManager(instanceConfig, instanceInfo);
    }
}
